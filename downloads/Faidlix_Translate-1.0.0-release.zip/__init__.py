bl_info = {
    "name": "Faidlix_Translate",
    "author": "Faidlix",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "Topbar > Before Workspace Tabs",
    "description": "Toggle the Blender interface between Traditional Chinese and the original language",
    "category": "Interface",
}

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import AddonPreferences, Operator

from .translations import TRANSLATIONS


ADDON_ID = __package__
TRANSLATION_DOMAIN = f"{__name__}.supplemental"
_ORIGINAL_DRAW_LEFT = None
_TRANSLATIONS_REGISTERED = False


def _addon_preferences(context=None):
    context = context or bpy.context
    addon = context.preferences.addons.get(ADDON_ID)
    return addon.preferences if addon else None


def _tag_redraw():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            area.tag_redraw()


def _save_preferences():
    if not bpy.context.preferences.use_preferences_save:
        return
    try:
        bpy.ops.wm.save_userpref()
    except (RuntimeError, AttributeError):
        # Preferences still remain active for this Blender session.
        pass


def _activate_traditional_chinese(preferences):
    view = bpy.context.preferences.view
    preferences.original_language = view.language
    preferences.original_interface = view.use_translate_interface
    preferences.original_tooltips = view.use_translate_tooltips
    preferences.original_reports = view.use_translate_reports
    preferences.original_new_data = view.use_translate_new_dataname

    view.language = "zh_HANT"
    view.use_translate_interface = True
    view.use_translate_tooltips = True
    view.use_translate_reports = True
    view.use_translate_new_dataname = True
    preferences.is_active = True


def _restore_original(preferences):
    view = bpy.context.preferences.view
    language = preferences.original_language
    enum_items = view.bl_rna.properties["language"].enum_items
    if language and language in enum_items:
        view.language = language
    view.use_translate_interface = preferences.original_interface
    view.use_translate_tooltips = preferences.original_tooltips
    view.use_translate_reports = preferences.original_reports
    view.use_translate_new_dataname = preferences.original_new_data
    preferences.is_active = False


class FAIDLIXTRANSLATE_Preferences(AddonPreferences):
    bl_idname = ADDON_ID

    is_active: BoolProperty(
        name="Traditional Chinese is active",
        default=False,
        options={"HIDDEN"},
    )
    original_language: StringProperty(default="en_US", options={"HIDDEN"})
    original_interface: BoolProperty(default=True, options={"HIDDEN"})
    original_tooltips: BoolProperty(default=True, options={"HIDDEN"})
    original_reports: BoolProperty(default=True, options={"HIDDEN"})
    original_new_data: BoolProperty(default=False, options={"HIDDEN"})

    def draw(self, _context):
        layout = self.layout
        layout.label(text="Use the globe button before the workspace tabs.", icon="WORLD")
        layout.label(text="First click: Traditional Chinese. Second click: restore the previous language.")
        layout.separator()
        layout.label(
            text="Add-ons without translation entries may keep some original text.",
            icon="INFO",
        )


class FAIDLIXTRANSLATE_OT_toggle(Operator):
    bl_idname = "faidlix_translate.toggle"
    bl_label = "切換繁體中文 / 原語系"
    bl_description = "第一次切換為繁體中文；再按一次恢復原本的語系設定"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        preferences = _addon_preferences(context)
        if preferences is None:
            self.report({"ERROR"}, "Faidlix_Translate preferences are unavailable")
            return {"CANCELLED"}

        if preferences.is_active:
            _restore_original(preferences)
            message = "已恢復原本的語系設定"
        else:
            _activate_traditional_chinese(preferences)
            message = "已切換為繁體中文"

        _tag_redraw()
        _save_preferences()
        self.report({"INFO"}, message)
        return {"FINISHED"}


def _draw_toggle(layout, context):
    preferences = _addon_preferences(context)
    active = bool(preferences and preferences.is_active)
    row = layout.row(align=True)
    row.operator(
        FAIDLIXTRANSLATE_OT_toggle.bl_idname,
        text="",
        icon="WORLD",
        depress=active,
    )


def _draw_left_with_translate(self, context):
    """Blender's standard left Topbar, with one button before workspace tabs."""
    from bl_ui.space_topbar import TOPBAR_MT_editor_menus

    layout = self.layout
    window = context.window
    screen = context.screen

    TOPBAR_MT_editor_menus.draw_collapsible(context, layout)
    layout.separator(type="LINE")
    _draw_toggle(layout, context)

    if not screen.show_fullscreen:
        layout.template_ID_tabs(
            window,
            "workspace",
            new="workspace.add",
            menu="TOPBAR_MT_workspace_menu",
        )
    else:
        layout.operator(
            "screen.back_to_previous",
            icon="SCREEN_BACK",
            text="Back to Previous",
        )


CLASSES = (
    FAIDLIXTRANSLATE_Preferences,
    FAIDLIXTRANSLATE_OT_toggle,
)


def _install_topbar_button():
    global _ORIGINAL_DRAW_LEFT
    header = bpy.types.TOPBAR_HT_upper_bar
    if _ORIGINAL_DRAW_LEFT is None:
        _ORIGINAL_DRAW_LEFT = header.draw_left
    header.draw_left = _draw_left_with_translate


def _remove_topbar_button():
    global _ORIGINAL_DRAW_LEFT
    if _ORIGINAL_DRAW_LEFT is None:
        return
    header = bpy.types.TOPBAR_HT_upper_bar
    if header.draw_left is _draw_left_with_translate:
        header.draw_left = _ORIGINAL_DRAW_LEFT
    _ORIGINAL_DRAW_LEFT = None


def register():
    global _TRANSLATIONS_REGISTERED
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    try:
        bpy.app.translations.register(TRANSLATION_DOMAIN, TRANSLATIONS)
        _TRANSLATIONS_REGISTERED = True
    except ValueError:
        _TRANSLATIONS_REGISTERED = False

    _install_topbar_button()
    _tag_redraw()


def unregister():
    global _TRANSLATIONS_REGISTERED
    preferences = _addon_preferences()
    if preferences and preferences.is_active:
        _restore_original(preferences)
        _save_preferences()

    _remove_topbar_button()

    if _TRANSLATIONS_REGISTERED:
        try:
            bpy.app.translations.unregister(TRANSLATION_DOMAIN)
        except ValueError:
            pass
        _TRANSLATIONS_REGISTERED = False

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    _tag_redraw()


if __name__ == "__main__":
    register()

