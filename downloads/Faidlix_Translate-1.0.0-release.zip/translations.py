"""Supplemental Traditional Chinese terms shared by common third-party add-ons.

Blender's own catalog remains the primary translation source.  These entries
cover common add-on labels that are often shipped without a locale catalog.
"""


_TERMS = {
    # Auto-Rig Pro and rigging tools.
    "Rig": "綁定",
    "Skin": "蒙皮",
    "Misc": "其他",
    "Add Armature": "新增骨架",
    "Custom Shapes": "自訂形狀",
    "Pose Tools": "姿勢工具",
    "Smart": "智慧綁定",
    "Remap": "重映射",
    "Export": "匯出",
    "Import": "匯入",
    "Armature": "骨架",
    "Bone": "骨骼",
    "Bones": "骨骼",
    "Pose": "姿勢",
    "Bind": "綁定",
    "Unbind": "解除綁定",
    "Weight": "權重",
    "Weights": "權重",
    "Mirror": "鏡像",
    "Generate": "產生",
    "Match": "匹配",
    "Apply Pose": "套用姿勢",
    "Reset Pose": "重設姿勢",
    "Picker": "選取器",
    # Common add-on controls.
    "Options": "選項",
    "Settings": "設定",
    "Advanced": "進階",
    "General": "一般",
    "Tools": "工具",
    "Create": "建立",
    "Delete": "刪除",
    "Remove": "移除",
    "Add": "新增",
    "Update": "更新",
    "Refresh": "重新整理",
    "Select": "選取",
    "Select All": "全部選取",
    "Clear": "清除",
    "Cancel": "取消",
    "Confirm": "確認",
    "Enable": "啟用",
    "Disable": "停用",
    "Enabled": "已啟用",
    "Disabled": "已停用",
    "Preview": "預覽",
    "Render": "算圖",
    "Material": "材質",
    "Materials": "材質",
    "Texture": "貼圖",
    "Textures": "貼圖",
    "Object": "物件",
    "Objects": "物件",
    "Collection": "集合",
    "Output": "輸出",
    "Input": "輸入",
    "Source": "來源",
    "Target": "目標",
    "Mode": "模式",
    "Quality": "品質",
    "Size": "尺寸",
    "Width": "寬度",
    "Height": "高度",
    "Path": "路徑",
    "File": "檔案",
    "Name": "名稱",
    "Search": "搜尋",
    "Help": "說明",
    "About": "關於",
}


TRANSLATIONS = {
    "zh_HANT": {
        ("*", english): traditional_chinese
        for english, traditional_chinese in _TERMS.items()
    }
}

