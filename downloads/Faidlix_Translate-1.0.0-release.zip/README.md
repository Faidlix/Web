# Faidlix_Translate

Blender 4.2+ add-on that adds a globe button immediately before the workspace
tabs in the top bar.

- First click: switches Blender to Traditional Chinese (`zh_HANT`) and enables
  interface, tooltip, report, and new-data-name translation.
- Second click: restores the language and translation switches that were active
  before the first click.
- Disabling the add-on while translation is active also restores the original
  settings.
- Includes supplemental Traditional Chinese terms commonly used by third-party
  add-ons, including the Auto-Rig Pro labels shown in the reference image.

Blender can only translate a string when it exists in Blender's catalog or in
an add-on translation dictionary. Brand-specific text from add-ons that provide
no translations may therefore remain in its original language.

## Install

Install `Faidlix_Translate-1.0.0.zip` through Blender's Extensions preferences,
then enable **Faidlix_Translate**. The globe button appears before the workspace
tabs (for example, immediately before the left arrow and `AR` tab in the
reference layout).

